/***********************************************************************
Write a function `valuePair(obj1, obj2, key)` that takes in two objects
and a key (string). The function should return an array containing the
corresponding values of the objects for the given key.

Examples:
***********************************************************************/
/**I am getting the right result. I know I'm breaking the DRY principle, but
 nothing from the lessons explains how to do this, and I can't find ANYTHING 
 online. I tried spreading into an object, but the properties/keys get overwritten
 let objectArray = {...obj1, ...obj2} doesn't work
 */

let object1 = {name: 'One', location: 'NY', age: 3};
let object2 = {name: 'Two', location: 'SF'};
valuePair(object1, object2, 'location'); // => [ 'NY', 'SF' ]
valuePair(object1, object2, 'name'); // => [ 'One', 'Two' ]

function valuePair(obj1, obj2, key) {
  // Your code here
    let result = [];
    for(let property in obj1){
        if(property === key){
            result.push(obj1[key])
        }
    }
    for(let property in obj2){
        if(property === key){
            result.push(obj2[key])
        }
    }
    console.log(result)

}

/**************DO NOT MODIFY ANYTHING UNDER THIS  LINE*****************/
module.exports = valuePair;